/*4. Write a technical example of Single level Inheritance.*/
 
