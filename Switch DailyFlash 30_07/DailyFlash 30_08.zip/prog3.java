class Switch{

	public static void main(String [] args){
	
		String RTO_code="MH";

		switch(RTO_code){
		
			case "MH":
				System.out.println("Maharashtra");
				break;
			case "AP":
				System.out.println("Andhra Pradesh");
				break;
			case "RJ":
				System.out.println("Rajsthan");
				break;
			case "UP":
				System.out.println("Uttar Pradesh");
				break;
			case "GJ":
				System.out.println("Gujrat");
				break;
		}


	}
}
