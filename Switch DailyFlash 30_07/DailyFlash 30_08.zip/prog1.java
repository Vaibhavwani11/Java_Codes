/*
	Write a program to get any number from user and check whether the entered number is greater than less than or equal to zero	 
I/P=0
O/p= Number is 0
*/
class prog1{

	public static void main(String [] args){
	
		int num=-5;
	
		if(num==0){
			System.out.println("Number is Zero ");
		}

		else if(num>0){
			System.out.println("Number is Greater than Zero");
			}
		
		else {
			System.out.println("Number is Negative" );
		}
	
	

	}
}
