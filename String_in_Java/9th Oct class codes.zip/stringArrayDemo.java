class stringDemo{

	public static void main(String [] args){
	
		string s1="Core2Web"; //String literal {String constant pool var jaga}

		String s2= new String("Biencaps"); //String Object {Heap var jaga}

		System.out.println(s1);
		System.out.println(s2);
	}
}
