class UnsignedRshift{
	public static void main(String [] args){
		int num=-35;
		int res=0;
		res= num>>25;
		System.out.println(res);
	}
}