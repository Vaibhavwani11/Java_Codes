//Cyclic Inheritance is not supported
/*
class A extends A{   //Error

}*/

class A extends B{

}
class B extends A{

}
