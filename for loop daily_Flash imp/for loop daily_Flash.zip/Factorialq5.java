class Factorial{

	public static void main(String [] args){
	
		int  fact=1;
		int cnt=1;
	
		while(cnt<=10){
		
			fact=fact*cnt;

			System.out.println("Factorial of "+cnt+"="+fact);
			cnt++;
		}
	
	}

			
	
}

