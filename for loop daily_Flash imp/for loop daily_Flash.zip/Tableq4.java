class Table{

	public static void main(String [] args){
	
		int num=4;
		int cnt=10;

		while(cnt>=1){
		
			System.out.println(num*cnt);
			cnt--;
		}
	}
}
