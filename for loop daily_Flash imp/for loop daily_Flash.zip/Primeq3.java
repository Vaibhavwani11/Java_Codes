class PrimeNo{

	public static void main(String [] args){
	
		int cnt=1;
		int num=11;
		int val=0;
			
		while(cnt<num){
		
			if(num%cnt==0){
		
				val++;
			}
		cnt++;
		}

		if(val==1)
			System.out.println(cnt+" is Prime Number");

		else
			System.out.println("Number is Not Prime Number");
		
		
	}
}
