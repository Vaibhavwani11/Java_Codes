class Addition{

	public static void main(String [] arghs){
	
		int i=1;
		int j=10;

		while(i<=10){

		
			System.out.println( i+" "+"+"+ j+"="+(i+j));
			i++;
			j--;
		}
	}
}
