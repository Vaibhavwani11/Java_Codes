class Core2Web{

	public static void main(String [] args){
	
		int var1=10;
		int var2=20;
int var3= var1 && var2;


		System.out.println(var3); // Error :-in JAVA logical operators works on boolean expressions i.e. boolean var3=(var1<var2)&& (var1!=0)	}
}
