class Core2Web{

	public static void main(String [] args){
	
		char var1= 'B';
		char var2= 'C';
	
		int var3= var1 & var2;
		System.out.println((char)var3);
	}
}
