class Core2Web{

	public static void main(String [] args){
	
		double var1=20.5;
		double var2= var1++;

		System.out.println(var2);	//20.5

		double var3= ++var1;	//22.5

		System.out.println(var3);
	}
}
