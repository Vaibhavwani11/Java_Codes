class Core2Web{

	public static void main(String [] args){
	
		int var1= 10;
		int var2= 20;
		 
		boolean var3=(var1==10 || var2==20);
	
		System.out.println(var3); //true
	}
}
