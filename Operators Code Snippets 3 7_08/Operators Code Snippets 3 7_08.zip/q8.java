class Core2Web{

	public static void main(String [] args){
	
		int var1=10;
		int var2=12;
		int var3= var1 & var2;

		System.out.println(var3);
	} 
	// 1010 & 1100 =1000 =8
}
