class Core2Web{

	public static void main(String [] args){
	
		char var1= 'A';
		char var2= 'B';

		System.out.println(var1>var2); //false [65 !> 66] 
	}
}
