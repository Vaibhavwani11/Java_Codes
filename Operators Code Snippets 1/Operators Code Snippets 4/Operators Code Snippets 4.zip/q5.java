
class Core2Web{

	public static void main(String [] args){
	
		char var = 'Z';
	
		System.out.println(--var++);
	}
}//Unexpected Type
