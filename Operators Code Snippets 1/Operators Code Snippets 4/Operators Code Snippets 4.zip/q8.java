
class Core2Web{

	public static void main(String [] args){
	
		
		System.out.println(10>>2);
	}
}//1010 >> 0010=0010  
