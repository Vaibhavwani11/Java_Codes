
class Core2Web{

	public static void main(String [] args){
	
		
		System.out.println(12==12 ? 12|2 : 22&10);
	}
} // 12|2= 1100 | 0010 =1110=14
