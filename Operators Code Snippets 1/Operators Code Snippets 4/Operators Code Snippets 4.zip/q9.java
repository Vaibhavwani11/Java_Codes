
class Core2Web{

	public static void main(String [] args){
	
		
		System.out.println(4<<4);
	}
}//0100 << 4=0100 0000  
