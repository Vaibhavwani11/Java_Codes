class Core2Web{

	public static void main(String [] args){
	
		int var =8&6^4|12;
	
		System.out.println(var);
	}
}
