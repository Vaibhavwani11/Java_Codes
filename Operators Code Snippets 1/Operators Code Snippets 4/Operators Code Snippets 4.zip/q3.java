
class Core2Web{

	public static void main(String [] args){
	
	
		System.out.println(14 % -4);
	}
}
// In this expression - operator has highest priority hence, -4 is converted into binary first which is 1100=12
// So, 14 % 12= 2
