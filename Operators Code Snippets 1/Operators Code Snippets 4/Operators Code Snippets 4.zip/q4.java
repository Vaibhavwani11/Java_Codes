
class Core2Web{

	public static void main(String [] args){
	
		boolean puneMetro =true;
		String s= puneMetro ? "Metro Running":"Metro not running";
		System.out.println(s);
	}
}
