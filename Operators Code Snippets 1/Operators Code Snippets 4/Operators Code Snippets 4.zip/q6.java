
class Core2Web{

	public static void main(String [] args){
	
		char var ='Z';
		char var1= 'T';

		System.out.println(var1= var--);// var1=Z var=Y
		System.out.println(--var1); // var1=Y
	}
}
