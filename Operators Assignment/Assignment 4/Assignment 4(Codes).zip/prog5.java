5:Write /*5:Write a Java code containing all the operators taught (Arithmetic, Logical,
Bitwise). Code must contain 3 Classes and one Main Class, where each class should
contain at least 1 static and 1 non static methods. No operations should be
performed in main class Except Object Creation and Calling the methods.*/
class Arithmetic{
		int a=10;
		static int b=15;
		
		void ArthDemo{
			
			
		}
		static void Arithmetic{
			
			
		}
	
}
class Logical{
	
	
}
class Bitwise{
	
	
}
class Main{
	public static void main(String [] args){
		
		
	}
}