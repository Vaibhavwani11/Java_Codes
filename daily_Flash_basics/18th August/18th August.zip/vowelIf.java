
/*
 Write a program to chec whether the character is vowel or consonant
Input:- a
Output:- a is vowel
 */
class dailyflash{
public static void main(String [] args){

	char ch='a';

	if(ch=='a' || ch=='e' || ch=='i' || ch=='o'|| ch=='u'){
	
		System.out.printf("%c is Vowel\n",ch);
	}
	else{
	
		System.out.printf("%c is a consonant\n",ch);
	}
}
}
