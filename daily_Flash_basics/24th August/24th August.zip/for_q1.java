
/*
 Write a program to print sum of first 10 natural numbers
Output: Sum of first 10 natural numbers=55
 */
class sum{
public static void main(String []args){

	

	for (int i=1; i<=10; i++){
	
		System.out.printf("%d ",i);
	}
	
}}
