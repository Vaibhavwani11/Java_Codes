class arrDemo{

	public static void main(String [] args){
	
		int arr[]={10,20,30,40,50};
		//int arr[5]={10,20,30,40,50}; This is not allowed}		

		for(int i=0; i<5; i++){
		                                                                                                                      
			System.out.println(arr[i]);
		}
	}
}
